//
//  ViewController.swift
//  MindCheck
//
//  Created by jafar on 13/05/22.
//

import UIKit
import Foundation


var timer = Timer()
var randBtn = "nil"
var scoreCount = 0
var timerCount = 0
var speed = 1.5
var alertTag = "0"
var level = "1"
var buttonTap = 0


class ViewController: UIViewController {
    
    @IBOutlet var Mainview: UIView!
    @IBOutlet weak var labeltext: UILabel!
    @IBOutlet weak var btnUp: UIButton!
    @IBOutlet weak var btnLeft: UIButton!
    @IBOutlet weak var btnRight: UIButton!
    @IBOutlet weak var btnDown: UIButton!
    @IBOutlet weak var btnStop: UIButton!
    @IBOutlet weak var btnStart: UIButton!
    @IBOutlet weak var labelTimerCount: UILabel!
    @IBOutlet weak var score: UILabel!
    @IBOutlet weak var currentLevel: UILabel!
    
    
    @IBAction func buttonUp(_ sender: Any) {
        btnUp.isEnabled = false
        buttonPress(checkpress: "buttonUp", currentButton: randBtn)
    }
    @IBAction func buttonLeft(_ sender: Any) {
        btnLeft.isEnabled = false
        buttonPress(checkpress: "buttonLeft", currentButton: randBtn)
    }
    @IBAction func buttonRight(_ sender: Any) {
        btnRight.isEnabled = false
        buttonPress(checkpress: "buttonRight", currentButton: randBtn)
    }
    @IBAction func buttonDown(_ sender: Any) {
        btnDown.isEnabled = false
        buttonPress(checkpress: "buttonDown", currentButton: randBtn)
    }
    
    @IBAction func buttonStart(_ sender: Any) {  timerStart()}
    @IBAction func buttonStop(_ sender: Any) {   reset()}
    
    
    var color:[String] = ["yellow","blue","red","green","brown","orange","purple",
                          "gray","violet","cream","maroon"]
    
    var colorCodeDict:[String:String] = [ "yellow":"#FFFF00FF", "blue":"#0000FFFF","red":"#FF0000FF","green":"#00FF00FF","brown":"#964B00FF","orange":"#ffbf00ff","purple":"#800080FF","gray":"#808080FF","violet":"#8F00FFFF","cream":"#FFFDD0FF","maroon":"#800000FF"]
    
    var randomBtn:[String] = ["buttonUp","buttonLeft","buttonRight","buttonDown"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @objc func startOperation()
{
        btnUp.isEnabled = true
        btnDown.isEnabled = true
        btnRight.isEnabled = true
        btnLeft.isEnabled = true
       var randomColorText = ""
        
            
        if String(timerCount) ==  String(scoreCount) {
            //choose random color from available color in array
            let randomColor = color.randomElement()
            //taking random color hex value from dict.
                    let index = color.firstIndex(of: randomColor!)
                    if index! == 10 {
                         randomColorText = color[0]
                    }else{
                         randomColorText = color[index! + 1]
                    }
                    
                    
            let data = colorCodeDict[randomColor!]
            labeltext.backgroundColor = UIColor(hex: data!) //set background hex color
            
            //taking random color from colortext array for text color
                if randomColorText == randomColor {
                    
                }
                       labeltext.text = randomColorText
            
            randBtn = randomBtn.randomElement()! // selecting random button from array
            
            switch randBtn {
            
            
            case "buttonUp":
                btnUp.backgroundColor = UIColor(hex: data!)
                btnDown.backgroundColor = generateRandomColor()
                let data2 = colorCodeDict[randomColorText]
                btnRight.backgroundColor = UIColor(hex: data2!)
                btnLeft.backgroundColor = generateRandomColor()
                
            case "buttonLeft":
                btnLeft.backgroundColor = UIColor(hex: data!)
                btnDown.backgroundColor = generateRandomColor()
                btnRight.backgroundColor = generateRandomColor()
                let data2 = colorCodeDict[randomColorText]
                btnUp.backgroundColor = UIColor(hex: data2!)
            case "buttonRight":
                btnRight.backgroundColor = UIColor(hex: data!)
                btnUp.backgroundColor = generateRandomColor()
                let data2 = colorCodeDict[randomColorText]
                btnDown.backgroundColor = UIColor(hex: data2!)
                btnLeft.backgroundColor = generateRandomColor()
            case "buttonDown":
                btnDown.backgroundColor = UIColor(hex: data!)
                btnUp.backgroundColor = generateRandomColor()
                btnRight.backgroundColor = generateRandomColor()
                let data2 = colorCodeDict[randomColorText]
                btnLeft.backgroundColor = UIColor(hex: data2!)
                
            default:
                return
            }
            timerCount = timerCount + 1
            labelTimerCount.text = String(timerCount)
            score.text = String(scoreCount)
        }else{
            
            Alert(tag: "1")
            stopTimer()
        }
    
        
}
    
    func Alert(tag :  String) -> Void {
        
        if tag == "1" {
            
           let alert = UIAlertController(title: "Game Over", message: "Score = \(scoreCount)", preferredStyle: .alert)
            let playAgain = UIAlertAction(title: "Play Again", style: .default) { (action) -> Void in
                self.reset()
                self.timerStart()
                
                    }
            
            let cancel = UIAlertAction(title: "Cancel", style: .default) { (action) -> Void in
                self.reset()
                }
            
            
            alert.addAction(playAgain)
            alert.addAction(cancel)
            self.present(alert, animated: true, completion: nil)
        }
        
        if tag == "2"
        {
            let alert = UIAlertController(title: String(scoreCount), message: "Score", preferredStyle: .alert)
            
        let nextLevel = UIAlertAction(title: "Play Next Level", style: .cancel) { (action) -> Void in
            
            if scoreCount == 10
            {
                self.timerSpeed(speedLevel: "2")
                level = "2"
            }
            else if scoreCount == 20
            {
                self.timerSpeed(speedLevel: "3")
                level = "3"
            }
            else if scoreCount == 30
            {
                self.timerSpeed(speedLevel: "4")
                level = "4"
            }
            else{
                self.timerSpeed(speedLevel: "1")
            }
            
                self.timerStart()
                }
            alert.addAction(nextLevel)
            self.present(alert, animated: true, completion: nil)
        
        }
        if tag == "3"{
            let alert = UIAlertController(title: String(scoreCount), message: "You Are Master mind", preferredStyle: .alert)
            stopTimer()
            let cancel = UIAlertAction(title: "Cancel", style: .default) { (action) -> Void in
                self.reset()
                }
            alert.addAction(cancel)
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    func timerStart() ->  Void{
        stopTimer()
        timer  = Timer.scheduledTimer(timeInterval: speed, target: self, selector: #selector(startOperation), userInfo: nil, repeats: true)
    }
    func reset() -> Void {
        timer.invalidate()
        score.text = "0"
        labelTimerCount.text = "0"
        randBtn = "nil"
        timerCount = 0
        speed = 1.5
        scoreCount = 0
        level = "1"
        alertTag = "0"
        currentLevel.text = "1"
        btnUp.isHidden = false
        btnDown.isHidden = false
        btnRight.isHidden = false
        btnLeft.isHidden = false
    }
    func stopTimer() -> Void {
        timer.invalidate()
        randBtn = "nil"
        
    }
    func timerSpeed(speedLevel : String) -> Void {
        
        if speedLevel == "1"
        {
            speed = 1.5
        }
        if speedLevel == "2"
        {
            speed = 1.250
        }
        if speedLevel == "3"
        {
            speed = 1.0
        }
        if speedLevel == "4"
        {
            speed = 0.750
        }
        currentLevel.text = speedLevel
    }
    func buttonPress(checkpress : String , currentButton :String) -> Void {
        if checkpress == currentButton  {
            scoreCount = scoreCount + 1
            score.text = String(scoreCount)
            
            if scoreCount == 10 || scoreCount == 20 || scoreCount == 30 {
                if  timerCount == scoreCount {
                    Alert(tag: "2")
                    stopTimer()
                }
                else{
                    Alert(tag: "1")
                    stopTimer()
                }
            }
            if scoreCount == 40 {
                Alert(tag: "3")
            }
            
        }else{
            
            Alert(tag: "1")
            stopTimer()
        }
        
    }
    
    func generateRandomColor() -> UIColor {
        let redValue = CGFloat.random(in: 0...1)
        let greenValue = CGFloat.random(in: 0...1)
        let blueValue = CGFloat.random(in: 0...1)
        
        let randomColor = UIColor(red: redValue, green: greenValue, blue: blueValue, alpha: 1.0)
        return randomColor
    }
}

extension UIColor {
    public convenience init?(hex: String) {
        let r, g, b, a: CGFloat

        if hex.hasPrefix("#") {
            let start = hex.index(hex.startIndex, offsetBy: 1)
            let hexColor = String(hex[start...])

            if hexColor.count == 8 {
                let scanner = Scanner(string: hexColor)
                var hexNumber: UInt64 = 0

                if scanner.scanHexInt64(&hexNumber) {
                    r = CGFloat((hexNumber & 0xff000000) >> 24) / 255
                    g = CGFloat((hexNumber & 0x00ff0000) >> 16) / 255
                    b = CGFloat((hexNumber & 0x0000ff00) >> 8) / 255
                    a = CGFloat(hexNumber & 0x000000ff) / 255

                    self.init(red: r, green: g, blue: b, alpha: a)
                    return
                }
            }
        }

        return nil
    }
}

