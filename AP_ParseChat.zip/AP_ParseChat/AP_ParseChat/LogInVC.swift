//
//  LogInVC.swift
//  AP_ParseChat
//
//  Created by admin on 2/10/17.
//  Copyright © 2017 admin. All rights reserved.
//

import UIKit

class LogInVC: UIViewController {
    var usersdata  = NSMutableArray()
    @IBOutlet weak var txt_mbl: UITextField!
    @IBOutlet weak var txt_password: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
//        let query = PFQuery(className: "product")
//        
//        query.findObjectsInBackground { (objects, error) in
//            print(objects)
//            for item in objects!{
//                item.deleteEventually()
//            }
//        }
//        let query2 = PFQuery(className: "ChatActivity")
//        
//        query2.findObjectsInBackground { (objects, error) in
//            print(objects)
//            for item in objects!{
//                item.deleteEventually()
//            }
//        }
//        let query3 = PFQuery(className: "productdata")
//        
//        query3.findObjectsInBackground { (objects, error) in
//            print(objects)
//            for item in objects!{
//                item.deleteEventually()
//            }
//        }

        self.usersdata.add("rahul")
        self.txt_mbl.text =   "jafar"
        self.txt_password.text =   "123"
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    ///-----------------Parse Login-----------------
    @IBAction func btn_signIn () {
        
        if self.txt_mbl.text?.characters.count == 0 {
            iToast.makeText("Contact not found").show()
            return
        }
        
        if self.txt_password.text?.characters.count == 0 {
            iToast.makeText("Password not found").show()
            return
        }
        
        print(self.txt_mbl.text! as String)
        print(self.txt_password.text! as String)
        
        PFUser.logInWithUsername(inBackground: self.txt_mbl.text! as String, password:self.txt_password.text! as String) { (user, error) in
            
            if error == nil {
                
                let installation   = PFInstallation.current()
                installation?["user_name"] = user?.username
                installation?.deviceToken = "123456"
                installation?.saveInBackground()
                user?["online_status"] = "1"
                user?.saveInBackground()
                
                
               // self.getInfo(username: (user?.username)!, email: (user?.email)!)
                var userc  = ProductPv()
                userc  = self.storyboard!.instantiateViewController(withIdentifier: "ProductPv") as! ProductPv
               
                userc.setsender(send: (user?.username)! as NSString)
                userc.setsenderemail(email: (user?.email)! as NSString)
                self.navigationController?.pushViewController(userc, animated: true)
                
                
                
                
            }  else {
                print("Error \(error)")
                print("Error \(error?.localizedDescription)")
            }
        }
        
    }
    
    
    
    @IBAction func btn_signup() {
        
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "SignUpVC") as! SignUpVC
        self.navigationController?.pushViewController(nextViewController, animated: true )
        
    }
    
}
extension Array where Element: Equatable {
    
    public func uniq() -> [Element] {
        var arrayCopy = self
        arrayCopy.uniqInPlace()
        return arrayCopy
    }
    
    mutating public func uniqInPlace() {
        var seen = [Element]()
        var index = 0
        for element in self {
            if seen.contains(element) {
                remove(at: index)
            } else {
                seen.append(element)
                index += 1
            }
        }
    }
}




//let query = PFQuery(className: "product")
//
//query.findObjectsInBackground { (objects, error) in
//    print(objects)
//    for item in objects!{
//        item.deleteEventually()
//    }
//}

