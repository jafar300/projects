//
//  allReceiverVc.swift
//  AP_ParseChat
//
//  Created by admin on 07/03/17.
//  Copyright © 2017 admin. All rights reserved.
//

import UIKit

class allReceiverVc: UIViewController ,UITableViewDelegate,UITableViewDataSource {
   
    
    var aryUser = NSMutableArray()
    var aryproduct = NSMutableArray()
    var productDetail  = NSMutableArray()
    var products = NSMutableArray()
    
    var lastmessgarray = NSMutableArray()
    var lastmessgobject = NSMutableArray()
    var chatdataarray = NSMutableArray()
    var chatobect = NSMutableArray()
    var usersdata  = NSMutableArray()
    
    var timerReloadUser : Timer!
    var timerFirst : Timer!
    
    var tagCategory = 0
    var serverresponse = 0
    var messgcheck = 5
    var queue     = 0
    var queue2    = 0
    var count     = 0
    var count2    = 0
    var queueReloadUser    = 0
    var count3 = 0
    var mainquery : PFQuery<PFObject>!
    var mainquery1 : PFQuery<PFObject>!
    var mainqueryy  : PFQuery<PFObject>!
    
    
    @IBOutlet weak var tblReceiverVc: UITableView!
    let appd = UIApplication.shared.delegate as! AppDelegate
     let installation   = PFInstallation.current()
    
    @IBAction func btnDocList(_ sender: AnyObject) {
        tagCategory = 3
        empty()
        self.product()
    }
    @IBAction func btnBuyList(_ sender: AnyObject) {
        tagCategory = 2
        empty()
        self.product()
    }
    @IBAction func btnSellList(_ sender: AnyObject) {
        tagCategory = 1
        empty()
        self.product()
    }
    @IBAction func btnAllList(_ sender: AnyObject) {
        tagCategory = 0
        empty()
        self.product()
    }

    
    
    override func viewWillAppear(_ animated: Bool) {
        
        let indexpath = appd.nilchatcount
        if (indexpath != nil){
            let cell: chatcell? = (self.tblReceiverVc.cellForRow(at: indexpath!) as? chatcell)
            cell?.unreadcount.text = ""
        }
         queueReloadUser = 0
         product()
    }

    
    @IBAction func btn_back() {
        
        self.navigationController?.popViewController(animated: true)
    }

    var sender = NSString()
    func setsender(send : NSString) {
        self.sender = send
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        tagCategory = 0
        self.tblReceiverVc.dataSource = self;
        self.tblReceiverVc.delegate = self;
    }
    
    func  tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath) as! chatcell
        
        if aryUser.count != 0 {
            
            let username  = String(describing: aryUser[indexPath.row])
            cell.username.text = username
            let prod  : String = ((self.aryproduct[indexPath.row] as AnyObject).value(forKey: "productname")! as? String)!
            cell.productName.text = prod
        }
        if lastmessgarray.count != 0 {
            let messg  = String(describing: lastmessgarray[indexPath.row])
            cell.messg.text = messg
         }
        if chatdataarray.count != 0 {
            let unreadcount  = String(describing: chatdataarray[indexPath.row])
            if unreadcount != "0"{
                queueReloadUser = 0
                product()
                cell.unreadcount.text = unreadcount
                
            }else{
                cell.unreadcount.text = ""
            }
        }
        if indexPath.row == aryUser.count - 1 {
           
            self.chatdataarray.removeAllObjects()
            self.lastmessgarray.removeAllObjects()
            
        }
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int  {
        return 1
    }
    
    
    func  tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return aryUser.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if  self.timerReloadUser != nil {
            self.timerReloadUser.invalidate()
            self.timerReloadUser = nil
        }
        
        var user  = chatsend()
        user  = self.storyboard!.instantiateViewController(withIdentifier: "chatsend") as! chatsend
        let a =  self.installation?["user_name"]
        
        let productName : NSString = ((self.aryproduct[indexPath.row] as AnyObject).value(forKey: "productname")! as? NSString)!
        let username : NSString = ((self.aryproduct[indexPath.row] as AnyObject).value(forKey: "username")! as? NSString)!
        let category : NSString = ((self.aryproduct[indexPath.row] as AnyObject).value(forKey: "category")! as? NSString)!
        user.setCategory(category: category)
        user.setproductName(email: productName)
        user.setuserName(email: username)
        let chatreceiver : NSString = aryUser[indexPath.row] as! NSString
        user.setreceiver(rec: chatreceiver)
        user.setsender(send: a! as! NSString)
        user.setsenderemail(email: a! as! NSString)
        self.navigationController?.pushViewController(user, animated: true)
    }

    
    
    func product(){
        
        let a =  self.installation?["user_name"]
        let ary = NSMutableArray()
        ary.add(a!)
        let query = PFQuery(className: "ChatActivity")
        let query3 = PFQuery(className: "ChatActivity")
        
        if tagCategory == 0 {
            
            query.whereKey("sender", containedIn: [ary as Any])
            query3.whereKey("receiver", containedIn: [ary as Any])
            mainqueryy = PFQuery.orQuery(withSubqueries: [query , query3])
        }
        
        if tagCategory == 1 {
            
            print([ary as Any])
            query.whereKey("username", containedIn: [ary as Any])
            mainqueryy = PFQuery.orQuery(withSubqueries: [query])
            
        }
        if tagCategory == 2 {
            
            query.whereKey("token", containedIn: [ary as Any])
            mainqueryy = PFQuery.orQuery(withSubqueries: [query])
        }
        
        if tagCategory == 3 {
            
            let aryy = NSMutableArray()
            aryy.add("gym")
            query.whereKey("category", containedIn:[aryy as Any])
            query3.whereKey("category", containedIn: [aryy as Any])
            mainqueryy = PFQuery.orQuery(withSubqueries: [query , query3])
        }
        
        
        
        
        mainqueryy.order(byDescending: "createdAt")
        mainqueryy.limit = 1000
        //mainqueryy.selectKeys(["productname"])
        var i = 1
        mainqueryy.findObjectsInBackground { (objects, error) in
            self.products.removeAllObjects()
            
            for item in objects!{
                
                        let rec = item.value(forKey: "productname")!
                        if self.products.contains(rec)
                        {}else{
                            self.products.add(rec)
                              }
                if i == objects!.count{
                  if self.timerFirst == nil {
                self.timerFirst = Timer.scheduledTimer(timeInterval: 0.1 , target: self, selector: #selector(self.reloadUser), userInfo: nil, repeats: true)
                    }
                }
                i = i + 1
            }
            
            
        }
    }
    
    func reloadUser(){
        
        if queueReloadUser == 0
        {
            queueReloadUser = 1
            if count3 == self.products.count
            {
                if count3 != 0 && self.products.count != 0 {
                    
                    if  self.timerFirst != nil {
                        self.timerFirst.invalidate()
                        self.timerFirst = nil
                        
                        self.timerReloadUser = Timer.scheduledTimer(timeInterval: 0.1 , target: self, selector: #selector(self.loadChat), userInfo: nil, repeats: true)
                        return
                    }
                    self.tblReceiverVc.reloadData()
                }
            }
            else{
                
                
        let a =  self.installation?["user_name"]
        let ary = NSMutableArray()
        ary.add(a!)
               
        let ary2 = NSMutableArray()
        ary2.add(self.products[count3])
        
        
        if tagCategory == 0{
    let query = PFQuery(className: "ChatActivity")
    query.whereKey("sender", containedIn: [ary as Any])
    query.whereKey("productname", containedIn: [ary2 as Any])
        
    let query3 = PFQuery(className: "ChatActivity")
    query3.whereKey("receiver", containedIn: [ary as Any])
     query3.whereKey("productname", containedIn: [ary2 as Any])
    
   mainquery1 = PFQuery.orQuery(withSubqueries: [query , query3])
            
                }
                
    if tagCategory == 1 {
    let query = PFQuery(className: "ChatActivity")
    query.whereKey("username", containedIn: [ary as Any])
    query.whereKey("productname", containedIn: [ary2 as Any])
    mainquery1 = PFQuery.orQuery(withSubqueries: [query])
                    
                }
                
if tagCategory == 2 {
    let query = PFQuery(className: "ChatActivity")
    query.whereKey("token", containedIn: [ary as Any])
    query.whereKey("productname", containedIn: [ary2 as Any])
    mainquery1 = PFQuery.orQuery(withSubqueries: [query])
                    
                }

                
                
            
    mainquery1.order(byDescending: "createdAt")
    mainquery1.limit = 1000
   // mainquery.selectKeys(["sender","receiver"])
    mainquery1.findObjectsInBackground { (objects, error) in
        
        self.queueReloadUser = 0
        self.count3 = self.count3 + 1
    
    for item in objects!{
           let checkuser  = item.value(forKey: "sender") as? String
           let checkuser2 = item.value(forKey: "receiver") as? String
    if (checkuser !=  checkuser2){
    
    if  (checkuser! == a! as! String){
    let rec = item.value(forKey: "receiver")!
    if self.usersdata.contains(rec)
    {}else{
    self.usersdata.add(rec)
    self.productDetail.add(item)
    }
    
    }else if (checkuser2! == a! as! String){
    
    let sender = item.value(forKey: "sender")!
    if self.usersdata.contains(sender)
    {}else{
    self.usersdata.add(sender)
    self.productDetail.add(item)    
         }
       }
     }
}
    
    for item in self.usersdata
    {
    self.aryUser.add(item)
    }
    for item in self.productDetail
        {
            self.aryproduct.add(item)
        }
            
            self.productDetail.removeAllObjects()
            self.usersdata.removeAllObjects()
            self.chatdataarray.removeAllObjects()
            self.lastmessgarray.removeAllObjects()
    
    
        }
      }
    }
  
}
    
    // last messg get mthod
    
    func lastMessg(){

        if queue2 == 0 {
            if count2 == aryUser.count
            {
                count2 = 0
            }
            else{
                queue2 = 1
                let ary2 = NSMutableArray()
                ary2.add(aryUser[count2])
                ary2.add(aryUser[count2])
                
                let a =  self.installation?["user_name"]
                let ary = NSMutableArray()
                ary.add(a!)

              
                
                let ary3 = NSMutableArray()
                let productName = ((aryproduct[count2] as AnyObject).value(forKey: "productname")! as? NSString)!
                ary3.add(productName)
                
                
                let query = PFQuery(className: "ChatActivity")
                query.whereKey("sender", containedIn: [ary as Any])
                query.whereKey("receiver", containedIn: [ary2 as Any])
                query.whereKey("productname", containedIn: [ary3 as Any])
                
                let query3 = PFQuery(className: "ChatActivity")
                query3.whereKey("sender", containedIn: [ary2 as Any])
                query3.whereKey("receiver", containedIn: [ary as Any])
                query3.whereKey("productname", containedIn: [ary3 as Any])
                mainquery = PFQuery.orQuery(withSubqueries: [query , query3])
                mainquery.order(byDescending: "createdAt")
                mainquery.limit = 1
                mainquery.selectKeys(["sender","receiver","message"])
                mainquery.findObjectsInBackground { (objects, error) in
                    
                    if objects?.count != 0
                    {
                        self.queue2 = 0
                        self.count2 = self.count2 + 1
                        self.lastmessgobject.add((objects![0]))
                        if self.lastmessgobject.count == self.aryUser.count
                        {
                            for item in self.lastmessgobject
                            {
                                let check = ((item as AnyObject).value(forKey: "message") as? String)
                                
                                if (check  != nil )
                                {
                                    
                                    let mes  = ((item as AnyObject).value(forKey: "message") as? String)!
                                    
                                    self.lastmessgarray.add(mes)
                                }
                                else{
                                    self.lastmessgarray.add("")
                                }
                            }
                            self.lastmessgobject.removeAllObjects()
                        }
                    }
                }
            }
        }
    }
    
    //this method return number of unread message count for per user
    func loadChat(){
        
        if aryUser.count == 0 {
            count = 0
            return
        }
           lastMessg()
            if queue == 0 {
                if count == aryUser.count
                {
                    count = 0
                }
                else
                {
                    
                    queue = 1
                    let ary2 = NSMutableArray()
                    ary2.add(aryUser[count])
                   
                    
                    let a =  self.installation?["user_name"]
                    let ary = NSMutableArray()
                    ary.add(a!)
                    
                    let ary3 = NSMutableArray()
                    let productName = ((aryproduct[count] as AnyObject).value(forKey: "productname")! as? NSString)!
                    ary3.add(productName)
                    
                    
                    let query = PFQuery(className: "ChatActivity")
                    query.whereKey("sender", containedIn: [ary as Any])
                    query.whereKey("receiver", containedIn: [ary2 as Any])
                    query.whereKey("productname", containedIn: [ary3 as Any])
                    
                    let query3 = PFQuery(className: "ChatActivity")
                    query3.whereKey("sender", containedIn: [ary2 as Any])
                    query3.whereKey("receiver", containedIn: [ary as Any])
                    query3.whereKey("productname", containedIn: [ary3 as Any])
                    
                    mainquery = PFQuery.orQuery(withSubqueries: [query , query3])
                    
                    let defaults = UserDefaults.standard
                    
                    let string = "\(productName)\(aryUser[count] as! String )"
                    if (defaults.value(forKey: string) != nil)
                    {
                       let date = defaults.value(forKey: string)!
                        
                       mainquery.whereKey("createdAt", greaterThan: date)
                    }
                    
                    mainquery.order(byDescending: "createdAt")
                    mainquery.limit = 50
                   // mainquery.selectKeys(["sender","receiver"])
                    mainquery.findObjectsInBackground { (objects, error) in
                        
                        self.queue = 0
                        self.count = self.count + 1
                        self.chatobect.add((objects?.count)!)
                        
                        if self.chatobect.count == self.aryUser.count
                        {
                            for item in self.chatobect
                            {
                                self.chatdataarray.add(item)
                            }
                            self.tblReceiverVc.reloadData()
                            self.chatobect.removeAllObjects()
                            
                        }
                    }
                }
            }
        
        
    }
    //load chat messg method end

    
    func empty()
    {
        
        if timerReloadUser != nil{
            timerReloadUser.invalidate()
            timerReloadUser = nil
        }
        if timerFirst != nil{
            timerFirst.invalidate()
            timerFirst = nil
        }
        if mainquery != nil
        {
            mainquery.cancel()
        }
        if mainquery1 != nil
        {
            mainquery1.cancel()
        }
        if mainquery1 != nil
        {
            mainqueryy.cancel()
        }
        
        serverresponse = 0
        messgcheck = 5
        queue     = 0
        queue2    = 0
        count     = 0
        count2    = 0
        queueReloadUser    = 0
        count3 = 0
        
        aryUser.removeAllObjects()
        aryproduct.removeAllObjects()
        productDetail.removeAllObjects()
        products.removeAllObjects()
        lastmessgarray.removeAllObjects()
        lastmessgobject.removeAllObjects()
        chatdataarray.removeAllObjects()
        chatobect.removeAllObjects()
        usersdata.removeAllObjects()
        self.tblReceiverVc.reloadData()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

   
}
