//
//  IQTitleBarButtonItem.h
//  Ever Green
//
//  Created by Khushboo Baghel on 03/10/15.
//  Copyright (c) 2015 Khushboo Baghel. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IQBarButtonItem.h"

@interface IQTitleBarButtonItem : IQBarButtonItem

-(id)initWithFrame:(CGRect)frame Title:(NSString *)title;

@end
