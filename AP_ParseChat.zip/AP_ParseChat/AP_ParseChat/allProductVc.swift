//
//  allProductVc.swift
//  AP_ParseChat
//
//  Created by admin on 07/03/17.
//  Copyright © 2017 admin. All rights reserved.
//

import UIKit

class allProductVc: UIViewController  ,UITableViewDelegate,UITableViewDataSource {
    @IBAction func btnBack(_ sender: AnyObject) {
         self.navigationController?.popViewController(animated: true)
        
    }
    var  products = NSMutableArray()
    var  productsDic = NSMutableDictionary()
    
    @IBOutlet weak var tblProduct: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblProduct.dataSource = self;
        self.tblProduct.delegate = self;
         getData()
        // Do any additional setup after loading the view.
    }

    
    func getData()
    {
        self.products.removeAllObjects()
        let installation   = PFInstallation.current()

        let mainquery = PFQuery(className: "product")
        mainquery.whereKey("username", notEqualTo: (installation?["user_name"])!)
        
        mainquery.order(byDescending: "createdAt")
        mainquery.limit = 1000
        
        mainquery.findObjectsInBackground { (objects, error) in
            print(objects)
            
            for item in objects!{
                
                var prod = ""
               
                if ((item.value(forKey: "productname") as? String) != nil){
                    self.products.add(item)
                }
            }
             self.tblProduct.reloadData()
            
        }
        
    }

    func  tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        
        cell.textLabel?.text = (self.products[indexPath.row] as AnyObject).value(forKey: "productname")! as? String
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int  {
        return 1
    }
    
    
    func  tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.products.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let installation   = PFInstallation.current()
        let chatreceiver : NSString = ((self.products[indexPath.row] as AnyObject).value(forKey: "username")! as? NSString)!
        let productName : NSString = ((self.products[indexPath.row] as AnyObject).value(forKey: "productname")! as? NSString)!
        let username : NSString = ((self.products[indexPath.row] as AnyObject).value(forKey: "username")! as? NSString)!
        let category : NSString = ((self.products[indexPath.row] as AnyObject).value(forKey: "category")! as? NSString)!
        
        registerUserForProduct(sender: (installation?["user_name"])! as! NSString, receiver: username, productName: productName, username: username, category: category)
        
        
        var user  = chatsend()
        user  = self.storyboard!.instantiateViewController(withIdentifier: "chatsend") as! chatsend
        user.setCategory(category: category)
        user.setproductName(email: productName)
        user.setuserName(email: username)
        user.setreceiver(rec: chatreceiver)
        user.setsender(send: (installation?["user_name"])! as! NSString)
        user.setsenderemail(email: (installation?["user_name"])! as! NSString)
         self.navigationController?.pushViewController(user, animated: true)
        
    }

    func registerUserForProduct(sender:NSString , receiver : NSString , productName: NSString , username : NSString , category : NSString){
    
        
        let query = PFQuery(className: "ChatActivity")
        query.whereKey("sender", equalTo: sender)
        query.whereKey("receiver", equalTo: receiver)
        query.whereKey("message", equalTo: "Chat start with \(receiver) for \(productName)")
        query.whereKey("productname", equalTo: productName)
        query.whereKey("username", equalTo: username)
        query.whereKey("token", equalTo: sender)
        query.whereKey("category", equalTo: category)

        
      let  mainquery1 = PFQuery.orQuery(withSubqueries: [query])
        mainquery1.findObjectsInBackground { (objects, error) in
            if objects?.count == 0 {
        
    let send = PFObject(className: "ChatActivity")
    send["sender"] = sender
    send["receiver"] = receiver
    send["message"] = "Chat start with \(receiver) for \(productName)"
    send["productname"] = productName
    send["username"] = username
    send["token"] = sender
    send["category"] = category
    send.saveInBackground()
            }else{
            return
            }
        }
}
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}







//let installation   = PFInstallation.current()
//let username = installation?["user_name"]
//
//let objectid = (self.products[indexPath.row] as AnyObject).value(forKey: "objectId")! as? String
//
//let query = PFQuery(className: "product")
//query.whereKey("objectId", equalTo: objectid!)
//query.findObjectsInBackground { (objects, error) in
//    
//    print(objects!)
//    
//    for user in objects! {
//        if user["token"] != nil
//        {
//            user["token"] = username
//            user.saveInBackground{
//                
//                (objects, error) in
//                var user  = chatsend()
//                user  = self.storyboard!.instantiateViewController(withIdentifier: "chatsend") as! chatsend
//                
//                
//                let productName : NSString = ((self.products[indexPath.row] as AnyObject).value(forKey: "productname")! as? NSString)!
//                let username : NSString = ((self.products[indexPath.row] as AnyObject).value(forKey: "username")! as? NSString)!
//                
//                
//                user.setproductName(email: productName)
//                user.setuserName(email: username)
//                user.setreceiver(rec: username)
//                user.setsender(send: (installation?["user_name"])! as! NSString)
//                user.setsenderemail(email: (installation?["user_name"])! as! NSString)
//                self.navigationController?.pushViewController(user, animated: true)
//            }
//        }else{
//        }
//        
//        
//        
//        
//    }
//}


