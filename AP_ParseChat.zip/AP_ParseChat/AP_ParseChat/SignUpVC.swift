//
//  SignUpVC.swift
//  AP_ParseChat
//
//  Created by admin on 2/15/17.
//  Copyright © 2017 admin. All rights reserved.
//

import UIKit

class SignUpVC: UIViewController {

    
    
    @IBOutlet weak var txt_email: UITextField!
    @IBOutlet weak var txt_mbl: UITextField!
    @IBOutlet weak var txt_password: UITextField!
     @IBOutlet weak var txt_userName: UITextField!
    
    var firsttimedate = NSDate()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.txt_userName.text = "aaaa"
        self.txt_mbl.text = "123456789"
        self.txt_email.text = "a@gmail.com"
        self.txt_password.text = "123456"
 
        // Do any additional setup after loading the view.
    }
 
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
      @IBAction func btn_back() {
        self.navigationController?.popViewController(animated: true)
        }
    
    
    @IBAction func btn_signup() {
        
        if self.txt_userName.text?.characters.count == 0 {
            iToast.makeText("UserName not found").show()
            return
        }
        
        if self.txt_mbl.text?.characters.count == 0 {
            iToast.makeText("Contact not found").show()
            return
        }
        
        if self.txt_email.text?.characters.count == 0 {
             iToast.makeText("Email not found").show()
            return
        }
        
        if self.txt_password.text?.characters.count == 0 {
             iToast.makeText("Password not found").show()
            return
        }
        
        let user = PFUser()
        user.email = self.txt_email.text! as String;
        user.username = self.txt_userName.text! as String;
        user.password = self.txt_password.text! as String;
        user["users_contact"] = self.txt_mbl.text! as String;
       //user["user_state"] = true
        
        user.signUpInBackground { (succeeded, error) in
            if succeeded {
                
                
                
                let installation = PFInstallation.current()
                installation?["user_name"] = user.username;
                let data = "hhh".data(using: .utf8)
                installation?.setDeviceTokenFrom(data)
                installation?.saveInBackground()
            }else{
                print(error?.localizedDescription)
                let alert = UIAlertController(title: "Alert 1", message: error?.localizedDescription, preferredStyle: UIAlertControllerStyle.alert);
                let cancelAction = UIAlertAction(title: "OK",   style: .cancel, handler: nil)
                alert.addAction(cancelAction)
                self.present(alert, animated: true)
            }
        }
    }
}




//let defaults = UserDefaults.standard
//if defaults.value(forKey: "signupdate") == nil
//{
//    defaults.setValue(true, forKey: "signupdate")
//    let ary = NSMutableArray()
//    ary.add(self.txt_userName.text! as String)
//    
//    let query4 = PFQuery(className: "_User")
//    query4.whereKey("username", containedIn: [ary as Any])
//    query4.findObjectsInBackground {(objects, error) in
//        self.firsttimedate  = objects?[0].value(forKey: "createdAt") as! NSDate
//        
//        defaults.set(self.firsttimedate , forKey: "lastmessgdate")
//        UserDefaults.standard.synchronize()
//    }}
