//
// UIWindow+Hierarchy.m
//  Ever Green
//
//  Created by Khushboo Baghel on 03/10/15.
//  Copyright (c) 2015 Khushboo Baghel. All rights reserved.
//

#import "UIWindow+Hierarchy.h"

#import <UIKit/UINavigationController.h>

#import "IQKeyboardManagerConstantsInternal.h"

IQ_LoadCategory(IQUIWindowHierarchy)


@implementation UIWindow (Hierarchy)

//  Function to get topMost ViewController object.
- (UIViewController*) topMostController
{
    UIViewController *topController = [self rootViewController];
    
    //  Getting topMost ViewController
    while ([topController presentedViewController])	topController = [topController presentedViewController];
	
    //  Returning topMost ViewController
    return topController;
}

- (UIViewController*)currentViewController;
{
    UIViewController *currentViewController = [self topMostController];
    
    while ([currentViewController isKindOfClass:[UINavigationController class]] && [(UINavigationController*)currentViewController topViewController])
        currentViewController = [(UINavigationController*)currentViewController topViewController];
    
    return currentViewController;
}


@end
