//
//  SWNinePatchImageView.h
//  SWNinePatchImageFactory
//
//  Created by shiami on 7/10/14.
//  Copyright (c) 2014 TaccoTap. All rights reserved.

#import <UIKit/UIKit.h>

@interface SWNinePatchImageView : UIImageView

@end
