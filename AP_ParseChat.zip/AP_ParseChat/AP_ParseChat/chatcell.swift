//
//  chatcell.swift
//  AP_ParseChat
//
//  Created by admin on 19/02/17.
//  Copyright © 2017 admin. All rights reserved.
//

import UIKit

class chatcell: UITableViewCell {

    @IBOutlet weak var productName: UILabel!
    @IBOutlet weak var labunread: UILabel!
    @IBOutlet weak var unreadcount: UILabel!
    
    @IBOutlet weak var username: UILabel!
    @IBOutlet weak var messg: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
