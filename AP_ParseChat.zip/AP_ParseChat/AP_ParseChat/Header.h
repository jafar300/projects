//
//  Header.h
//  AP_ParseChat
//AP_ParseChat/Header.h
//  Created by admin on 2/10/17.
//  Copyright © 2017 admin. All rights reserved.
//

#ifndef Header_h
#define Header_h

#import "Parse.h"
#import "iToast.h"
#import "SWNinePatchImageFactory.h"
#import "SWNinePatchImageView.h"

#import <UIImageView+UIActivityIndicatorForSDWebImage.h>
#import "SDImageCache.h"
#import "UIImageView+WebCache.h"
//#import <KeyboardManager/IQKeyboardManager.h>
//#import <KeyboardManager/IQKeyboardManagerConstants.h>
//#import <KeyboardManager/UIView+IQKeyboardToolbar.h>
#endif /* Header_h */
