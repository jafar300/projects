//
//  AllUserVC.swift
//  AP_ParseChat
//
//  Created by admin on 2/15/17.
//  Copyright © 2017 admin. All rights reserved.
//

import UIKit

class AllUserVC: UIViewController, UITableViewDelegate,UITableViewDataSource {

    var aryUser = NSMutableArray()
        
   
   
    @IBAction func btnBuyProduct(_ sender: AnyObject) {
        aryUser.removeAllObjects()
        buyProduct()
    }
    
    
    @IBAction func btnSellProduct(_ sender: AnyObject) {
        aryUser.removeAllObjects()
        sellProduct()
    }
    
    @IBAction func btnAllProduct(_ sender: AnyObject) {
        aryUser.removeAllObjects()
        allBuySellProduct()
        
    }
    @IBOutlet weak var tblList: UITableView!
    
    let appd = UIApplication.shared.delegate as! AppDelegate
    override func viewWillAppear(_ animated: Bool) {
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        aryUser.removeAllObjects()
        self.tblList.dataSource = self;
        self.tblList.delegate = self;
        allBuySellProduct()
    
    }
    
    var sender = NSString()
    func setsender(send : NSString) {
        self.sender = send
    }
    
    var senderemail  = NSString()
    func setsenderemail(email : NSString) {
        self.senderemail = email
    }
    
    
    @IBAction func btn_back() {
        self.navigationController?.popViewController(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
  //private  extension AllUserVC:  {
    
func  tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
 
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell2", for: indexPath)
    
    
        if aryUser.count != 0 {
            
            let username  = String(describing: aryUser[indexPath.row])
            
            cell.textLabel?.text = username
        }
    
    
            return cell
        }
        
    func numberOfSections(in tableView: UITableView) -> Int  {
    return 1 
    }
    
    
    func  tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
                              return aryUser.count
                             }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
            let installation   = PFInstallation.current()
        print((installation?["user_name"])!)
        
        let product = PFObject(className: "product")
       
        
        product["token"] = ""
        
        product.saveInBackground{
            (objects, error) in
            
        }
       
        
        
        
        var user  = allReceiverVc()
        user  = self.storyboard!.instantiateViewController(withIdentifier: "allReceiverVc") as! allReceiverVc
        
        print(aryUser)

        
        let sender : NSString = aryUser[indexPath.row] as! NSString
        
        user.setsender(send: sender)
        
        self.navigationController?.pushViewController(user, animated: true)
        
    }
    
    
    
    
    
    func sellProduct(){
        
        let ary = NSMutableArray()
        ary.add(self.sender)
        
        
        let mainquery = PFQuery(className: "product")
        mainquery.whereKey("userid", containedIn: [ary as Any])
        mainquery.order(byDescending: "createdAt")
        mainquery.limit = 100
        mainquery.selectKeys(["name"])
        
        mainquery.findObjectsInBackground { (objects, error) in
            print(objects)
            for item in objects!{
                
                let prod = (item.value(forKey: "name") as? String)!
                self.aryUser.add(prod)
                
            }
            
            print(self.aryUser)
            self.tblList.reloadData()
            
        }
    }
    
    
    func buyProduct(){
        
        let ary = NSMutableArray()
        ary.add(self.sender)
        
        let mainquery = PFQuery(className: "product")
        mainquery.whereKey("token", containedIn: [ary as Any])
        mainquery.order(byDescending: "createdAt")
        mainquery.limit = 100
        mainquery.selectKeys(["name"])
        
        mainquery.findObjectsInBackground { (objects, error) in
            print(objects)
            for item in objects!{
                
                let prod = (item.value(forKey: "name") as? String)!
                self.aryUser.add(prod)
                
            }
            
            
            
            
            
            self.tblList.reloadData()

        }
    }
    
    
    
    func allBuySellProduct(){
        
        let ary = NSMutableArray()
        ary.add(self.sender)
        
        let query = PFQuery(className: "product")
        query.whereKey("token", containedIn: [ary as Any])
        let quer3 = PFQuery(className: "product")
        quer3.whereKey("userid", containedIn: [ary as Any])
        let mainquery = PFQuery.orQuery(withSubqueries: [query , quer3])
        
        mainquery.order(byDescending: "createdAt")
        mainquery.limit = 100
        mainquery.selectKeys(["name"])
        
        mainquery.findObjectsInBackground { (objects, error) in
            print(objects)
            for item in objects!{
                
                let prod = (item.value(forKey: "name") as? String)!
                self.aryUser.add(prod)
                
            }
            
            self.tblList.reloadData()

        }
    }

    
    
    
 
}

