////
////  chatsend.swift
////  AP_ParseChat
////
////  Created by admin on 19/02/17.
////  Copyright © 2017 admin. All rights reserved.
////
//
//import UIKit
//
//class chatsend: UIViewController,UINavigationControllerDelegate    {
//    
//    
//    
//    
//    
//    @IBOutlet weak var viewchatbox: UIView!
//    @IBAction func btnattachfile(_ sender: AnyObject) {
//        self.present(imagePicker, animated: true, completion: nil)//4
//    }
//    @IBOutlet weak var imguser: UIImageView!
//    @IBOutlet weak var labusername: UILabel!
//    @IBOutlet weak var btnattachfile: UIButton!
//    @IBOutlet weak var labstatus: UILabel!
//    @IBOutlet weak var messageComposingView: UIView!
//    @IBOutlet weak var messageCointainerScroll: UIScrollView!
//    
//    @IBOutlet weak var buttomLayoutConstraint: NSLayoutConstraint!
//    
//    @IBOutlet weak var textField: UITextField!
//    @IBOutlet weak var sendButton: UIButton!
//    @IBAction func popvc(_ sender: AnyObject) {
//        
//        timer.invalidate()
//        self.navigationController?.popViewController(animated: true)
//    }
//    
//    @IBOutlet weak var popvc: UIButton!
//    @IBAction func btnsend(_ sender: AnyObject) {
//        send()
//    }
//    
//    //bubble data
//    var selectedImage : UIImage?
//    var lastChatBubbleY: CGFloat = 10.0
//    var internalPadding: CGFloat = 8.0
//    var lastMessageType: BubbleDataType?
//    var imagePicker = UIImagePickerController()
//    //bubble data end
//    
//    var aryUser = NSMutableArray()
//    var receiver =  NSString()
//    var sender = NSString()
//    var lastmessgdate = NSDate()
//    var statusdate = NSDate()
//    var queue = 5
//    var onoff = 5
//    var timer = Timer()
//    
//    var bubbleData = UIImage()
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
//        //bubble data
//        
//        imagePicker.delegate = self
//        imagePicker.allowsEditing = false //2
//        imagePicker.sourceType = .photoLibrary //3
//        sendButton.isEnabled = false
//        textField.isEnabled = true
//        
//        //  self.messageCointainerScroll.contentSize = CGSize(width: messageCointainerScroll.frame.width, height: lastChatBubbleY + internalPadding)
//        self.addKeyboardNotifications()
//        
//        let screenSize: CGRect = UIScreen.main.bounds
//        let screenWidth = screenSize.width
//        self.messageCointainerScroll.contentSize = CGSize(width: CGFloat(screenWidth), height: CGFloat(620))
//        self.messageCointainerScroll.contentInset = UIEdgeInsetsMake(0.0, 0.0,10, 0.0)
//        
//        //bubble data end
//        
//        textField.delegate = self
//        loadchat()
//        
//        
//        
//        
//        // Do any additional setup after loading the view.
//    }
//    
//    
//    
//    func setreceiver(rec : NSString) {
//        self.receiver = rec
//    }
//    func setsender(send : NSString) {
//        self.sender = send
//    }
//    var senderemail  = NSString()
//    func setsenderemail(email : NSString) {
//        self.senderemail = email
//    }
//    
//    
//    
//    func addKeyboardNotifications() {
//        
//        NotificationCenter.default.addObserver(self, selector: #selector(chatsend.keyboardWillShow(_:)), name:NSNotification.Name.UIKeyboardWillShow, object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(chatsend.keyboardWillHide(_:)), name:NSNotification.Name.UIKeyboardWillHide, object: nil)
//        
//    }
//    
//    func keyboardWillShow(_ notification: Notification) {
//        var info = (notification as NSNotification).userInfo!
//        let keyboardFrame: CGRect = (info[UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
//        
//        UIView.animate(withDuration: 1.0, animations: { () -> Void in
//            
//            self.buttomLayoutConstraint.constant = keyboardFrame.size.height
//            
//        }, completion: { (completed: Bool) -> Void in
//            self.moveToLastMessage()
//        })
//    }
//    
//    
//    func keyboardWillHide(_ notification: Notification) {
//        UIView.animate(withDuration: 1.0, animations: { () -> Void in
//            self.buttomLayoutConstraint.constant = 0.0
//        }, completion: { (completed: Bool) -> Void in
//            self.moveToLastMessage()
//        })
//    }
//    
//    
//    
//    @IBAction func sendButtonClicked(_ sender: AnyObject) {
//        self.addRandomTypeChatBubble()
//        textField.resignFirstResponder()
//    }
//    
//    func addRandomTypeChatBubble() {
//        var bubbleData = ChatBubbleData(text: textField.text, image: selectedImage, date: Date(), type: getRandomChatDataType())
//        addChatBubble(bubbleData)
//        
//    }
//    
//    // add chat bubble function
//    func addChatBubble(_ data: ChatBubbleData) {
//        
//        let padding:CGFloat = lastMessageType == data.type ? internalPadding/3.0 :  internalPadding
//        let chatBubble = ChatBubble(data: data, startY:lastChatBubbleY + padding)
//        self.messageCointainerScroll.addSubview(chatBubble)
//        
//        lastChatBubbleY = chatBubble.frame.maxY
//        
//        
//        self.messageCointainerScroll.contentSize = CGSize(width: messageCointainerScroll.frame.width, height: lastChatBubbleY + internalPadding)
//        self.moveToLastMessage()
//        lastMessageType = data.type
//        // textField.text = ""
//        sendButton.isEnabled = false //change kara hai
//    }
//    
//    
//    //function for move to last message
//    func moveToLastMessage() {
//        
//        if messageCointainerScroll.contentSize.height > messageCointainerScroll.frame.height {
//            let contentOffSet = CGPoint(x: 0.0, y: messageCointainerScroll.contentSize.height - messageCointainerScroll.frame.height)
//            self.messageCointainerScroll.setContentOffset(contentOffSet, animated: true)
//        }
//    }
//    func getRandomChatDataType() -> BubbleDataType {
//        return BubbleDataType(rawValue: Int(arc4random() % 2))!
//    }
//    
//    
//    
//    
//    func uploadimage() {
//        
//        
//        
//        let img = bubbleData
//        let imageData: Data = UIImageJPEGRepresentation(img, 0)!;
//        let base64 : String = imageData.base64EncodedString()
//        
//        let data = base64.data(using: String.Encoding.utf8)
//        let file = PFFile(name:"pics.png", data:data!)
//        
//        
//        file?.saveInBackground({ (succeeded , error ) -> Void in
//            
//            if succeeded {
//                
//                let send = PFObject(className: "ChatActivity")
//                
//                
//                print(file!)
//                send["sender"] = self.sender;
//                send["receiver"] = self.receiver
//                send["imageFile"] = file!
//                send["message"] = ""
//                send.saveInBackground{
//                    (objects, error) in
//                }
//                self.textField.text = nil
//                
//            }else {}
//            
//        }, progressBlock: { (amountDone: Int32) -> Void in
//            print(amountDone)
//        })
//        
//        
//        
//        
//    }
//    
//    
//    
//    
//    // send message function
//    func send() {
//        // print(receiver)
//        // print(sender)
//        // print(senderemail)
//        var string =  textField.text
//        var trimmedString : String!
//        while string?.characters.count != 0 && string?.characters.first == " " {
//            trimmedString = string?.trimmingCharacters(in: .whitespaces)
//            string = trimmedString
//        }
//        if (string?.characters.count)! != 0 {
//            while string?.characters.count != 0 && string?.characters.last == " " {
//                trimmedString = string?.trimmingCharacters(in: .whitespaces)
//                string = trimmedString
//            }
//            let send = PFObject(className: "ChatActivity")
//            send["sender"] = self.sender;
//            send["receiver"] = receiver
//            send["message"] = string! ;
//            send.saveInBackground()
//            self.textField.text = nil
//        }else{
//            self.textField.text = nil
//        }
//    }
//    
//    //load chat first time
//    func loadchat()  {
//        
//        let ary2 = NSMutableArray()
//        ary2.add(receiver)
//        ary2.add(receiver)
//        
//        let query4 = PFQuery(className: "_User")
//        query4.whereKey("username", containedIn: [ary2 as Any])
//        query4.findObjectsInBackground {(objects, error) in
//            
//            self.onoff = 0
//            if objects?.count != 0 {
//                let checkuser = objects![0]
//                self.statusdate = checkuser.value(forKey: "createdAt") as! NSDate
//                
//                
//                var useronlinestatus : String!
//                var useronlinestatusandroid : Int!
//                
//                if checkuser.value(forKey: "online_status") != nil
//                {
//                    
//                    useronlinestatus  = checkuser.value(forKey: "online_status") as! String!
//                    
//                    let c =  useronlinestatus
//                    
//                    if c == "2"
//                    {   self.labstatus.textColor = .red
//                        self.labstatus.text = "offline"
//                    }else{
//                        self.labstatus.textColor = .green
//                        self.labstatus.text = "online"
//                    }
//                }
//                if checkuser.value(forKey: "online") != nil
//                {
//                    useronlinestatusandroid  = checkuser.value(forKey: "online")! as! Int
//                    if useronlinestatusandroid == 0
//                    {   self.labstatus.textColor = .red
//                        self.labstatus.text = "offline"
//                    }else{
//                        self.labstatus.textColor = .green
//                        self.labstatus.text = "online"
//                    }
//                }
//            }
//            // online
//        }
//        var i = 0
//        self.aryUser.removeAllObjects()
//        
//        let ary = NSMutableArray()
//        ary.add(sender)
//        ary.add(senderemail)
//        
//        let query = PFQuery(className: "ChatActivity")
//        query.whereKey("sender", containedIn: [ary as Any])
//        query.whereKey("receiver", containedIn: [ary2 as Any])
//        
//        let query3 = PFQuery(className: "ChatActivity")
//        query3.whereKey("sender", containedIn: [ary2 as Any])
//        query3.whereKey("receiver", containedIn: [ary as Any])
//        
//        let mainquery = PFQuery.orQuery(withSubqueries: [query , query3])
//        mainquery.limit = 50
//        mainquery.order(byDescending: "createdAt")
//        mainquery.findObjectsInBackground { (objects, error) in
//            
//            i = (objects?.count)!
//            for item in objects!{
//                self.queue = 0
//                self.aryUser.add(objects![i - 1])
//                if i == (objects?.count)!
//                {
//                    self.lastmessgdate = item.value(forKey: "createdAt") as! NSDate
//                    
//                    let defaults = UserDefaults.standard
//                    defaults.set(self.lastmessgdate , forKey: "lastmessgdate")
//                    UserDefaults.standard.synchronize()
//                    
//                    print(self.lastmessgdate)
//                }
//                i = i - 1
//            }
//            
//            for item in self.aryUser{
//                
//                let checkuser = (item as AnyObject).value(forKey: "sender") as? String
//                
//                if  (checkuser! == self.sender as String || checkuser! == self.sender as String) {
//                    self.chatsender(item: item as AnyObject)
//                }
//                
//                if  (checkuser! == self.receiver as String) {
//                    
//                    self.chatreceiver(item: item as AnyObject)
//                    
//                }
//            }
//            self.timer = Timer.scheduledTimer(timeInterval: 0.5 , target: self, selector: #selector(self.updatedata), userInfo: nil, repeats: true);
//            
//        }
//        
//        
//    }
//    
//    
//    
//    func chatsender(item : AnyObject)
//    {
//        
//        let mes  = (item as AnyObject).value(forKey: "message") as? String
//        
//        if ((item as AnyObject).value(forKey: "imageFile") as? String != nil && (item as AnyObject).value(forKey: "imageFile") as? String != ""){
//            
//            let img  = ((item as AnyObject).value(forKey: "imageFile") as? String)!
//            
//            
//            var image =  UIImage()
//            let imageData = NSData(base64Encoded:img)
//            if imageData != nil {
//                if mes == nil{
//                    
//                    image = UIImage(data: imageData as! Data)!
//                    let chatBubbleData3 = ChatBubbleData(text: "", image:image, date: Date(), type: .mine)
//                    self.addChatBubble(chatBubbleData3)
//                }else{
//                    image = UIImage(data: imageData as! Data)!
//                    let chatBubbleData3 = ChatBubbleData(text: mes, image:image, date: Date(), type: .mine)
//                    self.addChatBubble(chatBubbleData3)
//                }
//                
//                
//            }
//        }else{
//            
//            let chatBubbleData3 = ChatBubbleData(text: mes, image:nil, date: Date(), type: .mine)
//            self.addChatBubble(chatBubbleData3)
//        }
//        
//        
//    }
//    
//    
//    
//    func chatreceiver(item : AnyObject)
//    {
//        
//        let mes  = (item as AnyObject).value(forKey: "message") as? String
//        if ((item as AnyObject).value(forKey: "imageFile") as? String != nil && (item as AnyObject).value(forKey: "imageFile") as? String != ""){
//            
//            let img  = ((item as AnyObject).value(forKey: "imageFile") as? String)!
//            
//            var image =  UIImage()
//            let imageData = NSData(base64Encoded:img)
//            if imageData != nil {
//                if mes == nil{
//                    
//                    image = UIImage(data: imageData as! Data)!
//                    let chatBubbleData3 = ChatBubbleData(text: "", image:image, date: Date(), type: .opponent)
//                    self.addChatBubble(chatBubbleData3)
//                }else{
//                    image = UIImage(data: imageData as! Data)!
//                    let chatBubbleData3 = ChatBubbleData(text: mes, image:image, date: Date(), type: .opponent)
//                    self.addChatBubble(chatBubbleData3)
//                }
//                
//            }
//        }else{
//            
//            let chatBubbleData3 = ChatBubbleData(text: mes, image:nil, date: Date(), type: .opponent)
//            self.addChatBubble(chatBubbleData3)
//        }
//    }
//    
//    
//    
//    
//    // update chat in every 05 sec timer in view did load
//    func updatedata()  {
//        
//        let ary2 = NSMutableArray()
//        ary2.add(receiver)
//        ary2.add(receiver)
//        
//        if onoff == 0 {
//            self.onoff = 1
//            
//            let query4 = PFQuery(className: "_User")
//            query4.whereKey("username", containedIn: [ary2 as Any])
//            // query4.whereKey("createdAt", greaterThan: statusdate as Any)
//            query4.whereKey("createdAt", greaterThanOrEqualTo: statusdate as Any)
//            query4.order(byDescending: "createdAt")
//            query4.findObjectsInBackground {(objects, error) in
//                //online check method start
//                
//                if objects?.count != 0 {
//                    self.onoff = 0
//                    let checkuser = objects![0]
//                    self.statusdate = checkuser.value(forKey: "createdAt") as! NSDate
//                    
//                    var useronlinestatus : String!
//                    var useronlinestatusandroid : Int!
//                    if checkuser.value(forKey: "online_status") != nil
//                    {
//                        useronlinestatus  = checkuser.value(forKey: "online_status") as! String!
//                        let c =  useronlinestatus
//                        if c == "2"
//                        {   self.labstatus.textColor = .red
//                            self.labstatus.text = "offline"
//                        }else{
//                            self.labstatus.textColor = .green
//                            self.labstatus.text = "online"
//                        }
//                    }
//                    if checkuser.value(forKey: "online") != nil
//                    {
//                        useronlinestatusandroid  = checkuser.value(forKey: "online")! as! Int
//                        if useronlinestatusandroid == 0
//                        {   self.labstatus.textColor = .red
//                            self.labstatus.text = "offline"
//                        }else{
//                            self.labstatus.textColor = .green
//                            self.labstatus.text = "online"
//                        }
//                    }
//                    
//                }else{
//                    self.onoff = 0
//                }
//            }
//        }
//        // online check logic end
//        
//        if queue == 0 {
//            queue = 1
//            var i = 0
//            self.aryUser.removeAllObjects()
//            
//            let ary = NSMutableArray()
//            ary.add(sender)
//            ary.add(senderemail)
//            
//            let query = PFQuery(className: "ChatActivity")
//            query.whereKey("sender", containedIn: [ary as Any])
//            query.whereKey("receiver", containedIn: [ary2 as Any])
//            
//            let query3 = PFQuery(className: "ChatActivity")
//            query3.whereKey("sender", containedIn: [ary2 as Any])
//            query3.whereKey("receiver", containedIn: [ary as Any])
//            
//            let mainquery = PFQuery.orQuery(withSubqueries: [query , query3])
//            
//            // print(lastmessgdate)
//            mainquery.whereKey("createdAt", greaterThan: lastmessgdate as Any)
//            mainquery.order(byDescending: "createdAt")
//            mainquery.limit = 50
//            mainquery.findObjectsInBackground { (objects, error) in
//                self.queue = 0
//                
//                
//                i = (objects?.count)!
//                
//                if i !=  0
//                {
//                    print(objects)
//                }
//                
//                for item in objects!{
//                    self.aryUser.add(objects![i - 1])
//                    if i == (objects?.count)!
//                    {
//                        self.lastmessgdate = item.value(forKey: "createdAt") as! NSDate
//                        
//                        let defaults = UserDefaults.standard
//                        defaults.set(self.lastmessgdate , forKey: "lastmessgdate")
//                        UserDefaults.standard.synchronize()
//                        print(self.lastmessgdate)
//                    }
//                    i = i - 1
//                }
//                
//                for item in self.aryUser{
//                    
//                    let checkuser = (item as AnyObject).value(forKey: "sender") as? String
//                    
//                    if  (checkuser! == self.sender as String || checkuser! == self.sender as String) {
//                        
//                        self.chatsender(item: item as AnyObject)
//                        
//                    }
//                    
//                    if  (checkuser! == self.receiver as String) {
//                        
//                        self.chatreceiver(item: item as AnyObject)
//                    }
//                    
//                }
//            }
//        }
//    }
//    
//    
//    
//    
//    
//    
//    
//    
//    
//    override func didReceiveMemoryWarning() {
//        super.didReceiveMemoryWarning()
//        // Dispose of any resources that can be recreated.
//    }
//    
//    
//    /*
//     // MARK: - Navigation
//     
//     // In a storyboard-based application, you will often want to do a little preparation before navigation
//     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//     // Get the new view controller using segue.destinationViewController.
//     // Pass the selected object to the new view controller.
//     }
//     */
//    
//    }
//    
//    
//    
//    extension chatsend: UITextFieldDelegate{
//        
//        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
//            // Send button clicked
//            textField.resignFirstResponder()
//            // self.addRandomTypeChatBubble()
//            textField.endEditing(true)
//            return true
//        }
//        
//        func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
//            var text: String
//            
//            if string.characters.count > 0 {
//                text = String(format:"%@%@",textField.text!, string);
//            } else {
//                var string = textField.text! as NSString
//                text = string.substring(to: string.length - 1) as String
//            }
//            if text.characters.count > 0 {
//                sendButton.isEnabled = true
//            } else {
//                sendButton.isEnabled = false
//            }
//            return true
//        }
//    }
//    
//    extension chatsend: UIImagePickerControllerDelegate{
//        //MARK: Delegates
//        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingImage image: UIImage!, editingInfo: [AnyHashable: Any]!) {
//            
//        }
//        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
//            picker.dismiss(animated: true, completion: { () -> Void in
//                
//            })
//        }
//        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [AnyHashable: Any]) {
//            
//            var chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage //2
//            
//            bubbleData = chosenImage
//            
//            //   bubbleData = ChatBubbleData(text: textField.text, image: chosenImage, date: Date(), type: getRandomChatDataType())
//            uploadimage()
//            // addChatBubble(bubbleData)
//            picker.dismiss(animated: true, completion: { () -> Void in
//                
//            })
//        }
//    }
//    //print(item.value(forKey: "createdAt"))



//let indexpath = IndexPath(row: 0, section: 0)
//
//let cell: HeaderCell? = (self.SignupTbl.cellForRow(at: indexpath) as? HeaderCell)
