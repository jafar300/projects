//
//  ProductPv.swift
//  AP_ParseChat
//
//  Created by admin on 07/03/17.
//  Copyright © 2017 admin. All rights reserved.
//

import UIKit

class ProductPv: UIViewController {
    @IBAction func allproduct(_ sender: AnyObject) {
        
        var user  = allProductVc()
       
        
        user  = self.storyboard!.instantiateViewController(withIdentifier: "allProductVc") as! allProductVc
       
        self.navigationController?.pushViewController(user, animated: true)

        
    }
    
    @IBOutlet weak var textCategory: UITextField!
    @IBAction func btnYourProduct(_ sender: AnyObject) {
       
        var user  = allReceiverVc()
        user  = self.storyboard!.instantiateViewController(withIdentifier: "allReceiverVc") as! allReceiverVc
        self.navigationController?.pushViewController(user, animated: true)
    }
    
    
    @IBOutlet weak var btnYourProduct: UIButton!
    @IBOutlet weak var textProductName: UITextField!

   
    @IBOutlet weak var btnProdAdd: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view.
    }

    
    var sender = NSString()
    func setsender(send : NSString) {
        self.sender = send
    }
    
    var senderemail  = NSString()
    func setsenderemail(email : NSString) {
        self.senderemail = email
    }

    @IBAction func btnProdAdd(_ sender: AnyObject) {
        
        let product = PFObject(className: "product")
        product["productname"] = self.textProductName.text
        product["username"] = self.sender
        product["bidders"] = ""
        product["category"] = self.textCategory.text
        
        product.saveInBackground{
            (objects, error) in
            self.textProductName.text = ""
            self.displayAlertMessage(messageToDisplay: "Product Add sucessfully")
        }
    }
    func displayAlertMessage(messageToDisplay: String)
    {
        let alertController = UIAlertController(title: "Alert", message: messageToDisplay, preferredStyle: .alert)
        
        let OKAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction!) in
            
            // Code in this block will trigger when OK button tapped.
            print("Ok button tapped");
            
        }
        
        alertController.addAction(OKAction)
        
        self.present(alertController, animated: true, completion: nil)
    }

    func getData()
    {
        let mainquery = PFQuery(className: "product")
        mainquery.order(byDescending: "createdAt")
        mainquery.limit = 1000
        mainquery.findObjectsInBackground { (objects, error) in
            print(objects)
            
            
        }
        
    }

    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

   
}
