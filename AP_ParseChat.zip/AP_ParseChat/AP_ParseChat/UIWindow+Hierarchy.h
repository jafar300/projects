//
// UIWindow+Hierarchy.h
//  Ever Green
//
//  Created by Khushboo Baghel on 03/10/15.
//  Copyright (c) 2015 Khushboo Baghel. All rights reserved.
//

#import <UIKit/UIWindow.h>

@class UIViewController;

@interface UIWindow (Hierarchy)

/*!
    @method topMostController
 
    @return Returns the current Top Most ViewController in hierarchy.
 */
- (UIViewController*) topMostController;

/*!
    @method currentViewController
 
    @return Returns the topViewController in stack of topMostController.
 */
- (UIViewController*)currentViewController;


@end
