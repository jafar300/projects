//
//  IQBarButtonItem.h
//  Ever Green
//
//  Created by Khushboo Baghel on 03/10/15.
//  Copyright (c) 2015 Khushboo Baghel. All rights reserved.
//

#import <UIKit/UIBarButtonItem.h>

@interface IQBarButtonItem : UIBarButtonItem

@end