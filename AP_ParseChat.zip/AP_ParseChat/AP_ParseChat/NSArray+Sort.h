//
//  NSArray+Sort.h
//  Ever Green
//
//  Created by Khushboo Baghel on 03/10/15.
//  Copyright (c) 2015 Khushboo Baghel. All rights reserved.
//

#import <Foundation/NSArray.h>

@interface NSArray (Sort)

/*!
    @method sortedArrayByTag
 
    @return Returns the array by sorting the UIView's by their tag property.
 */
- (NSArray*)sortedArrayByTag;

@end
