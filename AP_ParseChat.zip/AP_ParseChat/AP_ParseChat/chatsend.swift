//
//  chatsend.swift
//  AP_ParseChat
//
//  Created by admin on 19/02/17.
//  Copyright © 2017 admin. All rights reserved.
//

import UIKit

class chatsend: UIViewController,UINavigationControllerDelegate    {
    
    @IBOutlet weak var viewzoomout: UIView!
    @IBOutlet weak var btnzoomout: UIButton!
    @IBOutlet weak var imgzoom: UIImageView!
    @IBOutlet weak var progressbar: UIProgressView!
    @IBOutlet weak var progressview: UIView!
    
    @IBOutlet weak var viewchatbox: UIView!
    @IBOutlet weak var imguser: UIImageView!
    @IBOutlet weak var labusername: UILabel!
    @IBOutlet weak var btnattachfile: UIButton!
    @IBOutlet weak var labstatus: UILabel!
    @IBOutlet weak var messageComposingView: UIView!
    @IBOutlet weak var messageCointainerScroll: UIScrollView!
    @IBOutlet weak var buttomLayoutConstraint: NSLayoutConstraint!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var sendButton: UIButton!
    
    @IBOutlet weak var popvc: UIButton!
    
    @IBAction func btnattachfile(_ sender: AnyObject) {
        self.present(imagePicker, animated: true, completion: nil)//4
    }
    
    @IBAction func popvc(_ sender: AnyObject) {
        
        timer.invalidate()
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnzoomout(_ sender: AnyObject) {
        imageOut()
        
    }
    @IBAction func btnsend(_ sender: AnyObject) {
        send()
    }
    
    
    //bubble data
    var selectedImage : UIImage?
    var lastChatBubbleY: CGFloat = 10.0
    var internalPadding: CGFloat = 8.0
    var lastMessageType: BubbleDataType?
    var imagePicker = UIImagePickerController()
    //bubble data end
    
    var aryUser = NSMutableArray()
    var receiver =  NSString()
    var sender = NSString()
    var lastMessgDate = NSDate()
    var statusDate = NSDate()
    var queue = 5
    var onoff = 5
    var timer = Timer()
    
    
    var  taggg = 0
    var tap = UITapGestureRecognizer()
    var viewX :CGFloat!
    var viewY : CGFloat!
    var bubbleData = UIImage()
    
    override func viewWillAppear(_ animated: Bool) {
        let defaults = UserDefaults.standard
        if defaults.value(forKey: "lastmessgdate") != nil {
            defaults.setValue(nil, forKey: "lastmessgdate")
        }
        
    }
    
    override func viewDidLoad() {
        
        
        super.viewDidLoad()
        
        
        viewzoomout.isHidden =  true
        imgzoom.isHidden =  true
        progressview.isHidden =  true
        progressbar.progress = 0
        labusername.text = self.receiver as String
        
        //bubble data
        imagePicker.delegate = self
        imagePicker.allowsEditing = false //2
        imagePicker.sourceType = .photoLibrary //3
        sendButton.isEnabled = false
        textField.isEnabled = true
        
        self.addKeyboardNotifications()
        tap = UITapGestureRecognizer(target: self, action: #selector(doubleTapped))
        tap.numberOfTapsRequired = 1
        messageCointainerScroll.addGestureRecognizer(tap)
        let screenSize: CGRect = UIScreen.main.bounds
        let screenWidth = screenSize.width
        self.messageCointainerScroll.contentSize = CGSize(width: CGFloat(screenWidth), height: CGFloat(620))
        self.messageCointainerScroll.contentInset = UIEdgeInsetsMake(0.0, 0.0,10, 0.0)
        //bubble data end
        
        textField.delegate = self
        loadChat()
    }
    
    func setreceiver(rec : NSString) {
        self.receiver = rec
    }
    
    func setsender(send : NSString) {
        self.sender = send
    }
    
    var senderemail  = NSString()
    func setsenderemail(email : NSString) {
        self.senderemail = email
    }
    var productName  = NSString()
    func setproductName(email : NSString) {
        self.productName = email
    }
    var userName  = NSString()
    func setuserName(email : NSString) {
        self.userName = email
    }
    var category  = NSString()
    func setCategory(category : NSString) {
        self.category = category
    }
    
    func addKeyboardNotifications() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(chatsend.keyboardWillShow(_:)), name:NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(chatsend.keyboardWillHide(_:)), name:NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    func keyboardWillShow(_ notification: Notification) {
        var info = (notification as NSNotification).userInfo!
        let keyboardFrame: CGRect = (info[UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
        
        UIView.animate(withDuration: 1.0, animations: { () -> Void in
            
            self.buttomLayoutConstraint.constant = keyboardFrame.size.height
            
            }, completion: { (completed: Bool) -> Void in
                self.moveToLastMessage()
        })
    }
    
    func keyboardWillHide(_ notification: Notification) {
        UIView.animate(withDuration: 1.0, animations: { () -> Void in
            self.buttomLayoutConstraint.constant = 0.0
            }, completion: { (completed: Bool) -> Void in
                self.moveToLastMessage()
        })
    }
    
    
    // add chat bubble function
    func addChatBubble(_ data: ChatBubbleData) {
        
        let padding:CGFloat = lastMessageType == data.type ? internalPadding/3.0 :  internalPadding
        let chatBubble = ChatBubble(data: data, startY:lastChatBubbleY + padding)
        self.messageCointainerScroll.addSubview(chatBubble)
        
        lastChatBubbleY = chatBubble.frame.maxY
        
        self.messageCointainerScroll.contentSize = CGSize(width: messageCointainerScroll.frame.width, height: lastChatBubbleY + internalPadding)
        self.moveToLastMessage()
        lastMessageType = data.type
        // textField.text = ""
        sendButton.isEnabled = false //change kara hai
    }
    
    
    //function for move to last message
    func moveToLastMessage() {
        
        if messageCointainerScroll.contentSize.height > messageCointainerScroll.frame.height {
            let contentOffSet = CGPoint(x: 0.0, y: messageCointainerScroll.contentSize.height - messageCointainerScroll.frame.height)
            self.messageCointainerScroll.setContentOffset(contentOffSet, animated: true)
        }
    }
    
    //image upload
    func uploadImage() {
        
        progressview.isHidden =  false
        let img = bubbleData
        let imageData: Data = UIImageJPEGRepresentation(img, 0)!;
        let file = PFFile(name:"pics.png", data:imageData)
        file?.saveInBackground({ (objects, error)  in
            if objects {
                let send = PFObject(className: "ChatActivity")
                
                
                
                send["img"] = file?.url!
                send["message"] = ""
                send["sender"] = self.sender;
                send["receiver"] = self.receiver
                send["productname"] = self.productName;
                send["username"] = self.userName;
                send["token"] = "";
                send["category"] = self.category;
                
                
                
                send.saveInBackground{
                    (objects, error) in
                    if objects ==  true{
                        self.progressview.isHidden = true
                    }
                    else{
                        print(error)
                        self.displayAlertMessage(messageToDisplay: "Uploading fail")
                        self.progressview.isHidden = true
                    }
                }
                self.textField.text = nil
                
            }else {
                self.progressview.isHidden = true
                self.displayAlertMessage(messageToDisplay: "Uploading fail")
            }
            
            }, progressBlock: { (amountDone: Int32) -> Void in
                
                self.progressbar.progress = Float(amountDone)/100
        })
    }
    
    //image zoom in out function
    func doubleTapped() {
        
        let  result = tap.location(in: messageCointainerScroll)
        let  result2 = tap.location(in: self.view)
        for myView: UIView in messageCointainerScroll.subviews {
            if myView.frame.contains(result) {
                if (myView is ChatBubble) {
                    self.imgzoom.isHidden =  false
                    self.viewzoomout.isHidden = false
                    let top  = myView.frame.maxY - result.y + result2.y - 150
                    let veiwcentrex = myView.center.x
                    viewX = veiwcentrex
                    viewY = top
                    self.imgzoom.frame = CGRect(x: veiwcentrex - 50 , y: top - 25, width: 100 , height: 100)
                    
                    UIView.animate(withDuration: 1.0, animations: {
                        self.imgzoom.frame = CGRect(x: 0, y:ScreenSize.SCREEN_HEIGHT/7, width: ScreenSize.SCREEN_WIDTH, height:300)
                        let bubbledata: ChatBubble? = (myView as? ChatBubble)
                        self.imgzoom.image = bubbledata?.imageViewChat?.image
                    })
                }
            }
        }
    }
    
    
    //image zoom out
    func imageOut(){
        
        UIView.animate(withDuration: 1.0, animations: { () -> Void in
            self.imgzoom.frame = CGRect(x: self.viewX - 50 , y: self.viewY - 25, width: 100 , height: 100)
            }, completion: { (completed: Bool) -> Void in
                self.imgzoom.isHidden = true
                self.viewzoomout.isHidden =  true
        })
    }
    
    
    
    // send message function
    func send() {
        // print(receiver)
        // print(sender)
        // print(senderemail)
        
        var string =  textField.text
        var trimmedString : String!
        while string?.characters.count != 0 && string?.characters.first == " " {
            trimmedString = string?.trimmingCharacters(in: .whitespaces)
            string = trimmedString
        }
        if (string?.characters.count)! != 0 {
            while string?.characters.count != 0 && string?.characters.last == " " {
                trimmedString = string?.trimmingCharacters(in: .whitespaces)
                string = trimmedString
            }
            
            
            let send = PFObject(className: "ChatActivity")
            send["sender"] = self.sender;
            send["receiver"] = receiver
            send["message"] = string! ;
            send["productname"] = self.productName;
            send["username"] = self.userName;
            send["token"] = "";
            send["category"] = self.category;
            send.saveInBackground()

            self.textField.text = nil
        }else{
            self.textField.text = nil
        }
    }
    
    //load chat first time
    func loadChat()  {
        
        // first check online status
        let ary2 = NSMutableArray()
        ary2.add(receiver)
        ary2.add(receiver)
        
        let query4 = PFQuery(className: "_User")
        query4.whereKey("username", containedIn: [ary2 as Any])
        query4.findObjectsInBackground {(objects, error) in
            
            self.onoff = 0
            if objects?.count != 0 {
                let checkuser = objects![0]
                self.statusDate = checkuser.value(forKey: "createdAt") as! NSDate
                
                var useronlinestatus : String!
                var useronlinestatusandroid : Int!
                
                if checkuser.value(forKey: "online_status") != nil
                {
                    useronlinestatus  = checkuser.value(forKey: "online_status") as! String!
                    let c =  useronlinestatus
                    
                    if c == "2"
                    {   self.labstatus.textColor = .red
                        self.labstatus.text = "offline"
                    }else{
                        self.labstatus.textColor = .green
                        self.labstatus.text = "online"
                    }
                }
                if checkuser.value(forKey: "online") != nil
                {
                    useronlinestatusandroid  = checkuser.value(forKey: "online")! as! Int
                    if useronlinestatusandroid == 0
                    {   self.labstatus.textColor = .red
                        self.labstatus.text = "offline"
                    }else{
                        self.labstatus.textColor = .green
                        self.labstatus.text = "online"
                    }
                }
            }
            
            //check online end
        }
        // loading chat first time
        var i = 0
        self.aryUser.removeAllObjects()
        let ary = NSMutableArray()
        ary.add(sender)
        ary.add(senderemail)
        
        let ary3 = NSMutableArray()
        ary3.add(self.productName)
        
        
        let query = PFQuery(className: "ChatActivity")
        query.whereKey("sender", containedIn: [ary as Any])
        query.whereKey("receiver", containedIn: [ary2 as Any])
        query.whereKey("productname", containedIn: [ary3 as Any])
        
        let query3 = PFQuery(className: "ChatActivity")
        query3.whereKey("sender", containedIn: [ary2 as Any])
        query3.whereKey("receiver", containedIn: [ary as Any])
        query3.whereKey("productname", containedIn: [ary3 as Any])
        let mainquery = PFQuery.orQuery(withSubqueries: [query , query3])
        mainquery.limit = 50
        mainquery.order(byDescending: "createdAt")
        mainquery.findObjectsInBackground { (objects, error) in
            if objects?.count == 0
            {
                self.loadChat()
                return
            }

            i = (objects?.count)!
            for item in objects!{
                self.queue = 0
                self.aryUser.add(objects![i - 1])
                if i == (objects?.count)!
                {
                    self.lastMessgDate = item.value(forKey: "createdAt") as! NSDate
                    let productName = item.value(forKey: "productname")!
                    let username = self.receiver
                    let string = "\(productName)\(username)"
                    let defaults = UserDefaults.standard
                    defaults.set(self.lastMessgDate , forKey: string)
                    UserDefaults.standard.synchronize()
                    
                    
                }
                i = i - 1
            }
            
            for item in self.aryUser{
                
                self.taggg = self.taggg + 1
                let checkuser = (item as AnyObject).value(forKey: "sender") as? String
                
                if  (checkuser! == self.sender as String || checkuser! == self.sender as String) {
                    self.chatSender(item: item as AnyObject , tagdata: self.taggg)
                }
                
                if  (checkuser! == self.receiver as String) {
                    
                    self.chatReceiver(item: item as AnyObject , tagdata: self.taggg)
                    
                }
            }
            self.timer = Timer.scheduledTimer(timeInterval: 0.5 , target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true);
            
        }
    }
    
    
    
    
    // update chat in every 05 sec timer in view did load
    func updateData()  {
        
        let ary2 = NSMutableArray()
        ary2.add(receiver)
        ary2.add(receiver)
        
        if onoff == 0 {
            self.onoff = 1
            
            let query4 = PFQuery(className: "_User")
            query4.whereKey("username", containedIn: [ary2 as Any])
            // query4.whereKey("createdAt", greaterThan: statusdate as Any)
            query4.whereKey("createdAt", greaterThanOrEqualTo: statusDate as Any)
            query4.order(byDescending: "createdAt")
            query4.findObjectsInBackground {(objects, error) in
                //online check method start
                
                if objects?.count != 0 {
                    self.onoff = 0
                    let checkuser = objects![0]
                    self.statusDate = checkuser.value(forKey: "createdAt") as! NSDate
                    
                    var useronlinestatus : String!
                    var useronlinestatusandroid : Int!
                    if checkuser.value(forKey: "online_status") != nil
                    {
                        useronlinestatus  = checkuser.value(forKey: "online_status") as! String!
                        let c =  useronlinestatus
                        if c == "2"
                        {   self.labstatus.textColor = .red
                            self.labstatus.text = "offline"
                        }else{
                            self.labstatus.textColor = .green
                            self.labstatus.text = "online"
                        }
                    }
                    if checkuser.value(forKey: "online") != nil
                    {
                        useronlinestatusandroid  = checkuser.value(forKey: "online")! as! Int
                        if useronlinestatusandroid == 0
                        {   self.labstatus.textColor = .red
                            self.labstatus.text = "offline"
                        }else{
                            self.labstatus.textColor = .green
                            self.labstatus.text = "online"
                        }
                    }
                    
                }else{
                    self.onoff = 0
                }
            }
        }
        
        // online check logic end
        
        if queue == 0 {
            queue = 1
            var i = 0
            self.aryUser.removeAllObjects()
            
            let ary = NSMutableArray()
            ary.add(sender)
            ary.add(senderemail)
            
            let ary3 = NSMutableArray()
            ary3.add(self.productName)
            
            
            let query = PFQuery(className: "ChatActivity")
            query.whereKey("sender", containedIn: [ary as Any])
            query.whereKey("receiver", containedIn: [ary2 as Any])
            query.whereKey("productname", containedIn: [ary3 as Any])
            
            let query3 = PFQuery(className: "ChatActivity")
            query3.whereKey("sender", containedIn: [ary2 as Any])
            query3.whereKey("receiver", containedIn: [ary as Any])
            query3.whereKey("productname", containedIn: [ary3 as Any])
            let mainquery = PFQuery.orQuery(withSubqueries: [query , query3])
            
            // print(lastmessgdate)
            mainquery.whereKey("createdAt", greaterThan: lastMessgDate as Any)
            mainquery.order(byDescending: "createdAt")
            mainquery.limit = 50
            mainquery.findObjectsInBackground { (objects, error) in
                self.queue = 0
                i = (objects?.count)!
                
                if i !=  0
                {
                    print(objects)
                }
                
                for item in objects!{
                    self.aryUser.add(objects![i - 1])
                    if i == (objects?.count)!
                    {
                        self.lastMessgDate = item.value(forKey: "createdAt") as! NSDate
                        let productName = item.value(forKey: "productname")!
                        let username = self.receiver
                        let string = "\(productName)\(username)"
                        let defaults = UserDefaults.standard
                        defaults.set(self.lastMessgDate , forKey: string)
                        UserDefaults.standard.synchronize()
                        
                    }
                    i = i - 1
                }
                
                for item in self.aryUser{
                    self.taggg = self.taggg + 1
                    let checkuser = (item as AnyObject).value(forKey: "sender") as? String
                    
                    if  (checkuser! == self.sender as String || checkuser! == self.sender as String) {
                        
                        self.chatSender(item: item as AnyObject , tagdata :self.taggg)
                    }
                    
                    if  (checkuser! == self.receiver as String) {
                        
                        self.chatReceiver(item: item as AnyObject,tagdata :self.taggg)
                        
                    }
                }
            }
        }
    }
    
    
    
    // sender data extract
    func chatSender(item : AnyObject , tagdata : Int)
    {
        let datee = item.value(forKey: "createdAt")!
        let str : Date = datee as! Date
        
        let mes  = (item as AnyObject).value(forKey: "message") as? String
        
        if ((item as AnyObject).value(forKey: "img") as? String != nil && (item as AnyObject).value(forKey: "img") as? String != ""){
            
            let img  = ((item as AnyObject).value(forKey: "img") as? String)!
            
            if img.characters.count != 0 {
                if mes == nil{
                    
                    let chatBubbleData3 = ChatBubbleData(text: "", image:img as NSString?, date: str as Date, type: .mine , tagg:tagdata )
                    self.addChatBubble(chatBubbleData3)
                }else{
                    
                    let chatBubbleData3 = ChatBubbleData(text: mes, image:img as NSString?, date: str as Date, type: .mine , tagg : tagdata)
                    self.addChatBubble(chatBubbleData3)
                }
            }
        }else{
            
            let chatBubbleData3 = ChatBubbleData(text: mes, image:nil, date: str as Date, type: .mine , tagg : tagdata)
            self.addChatBubble(chatBubbleData3)
        }
    }
    
    
    // receiver data extract
    func chatReceiver(item : AnyObject , tagdata : Int)
    {
        let datee = item.value(forKey: "createdAt")!
        let str : Date = datee as! Date
        
        let mes  = (item as AnyObject).value(forKey: "message") as? String
        if ((item as AnyObject).value(forKey: "img") as? String != nil && (item as AnyObject).value(forKey: "img") as? String != ""){
            
            let img  = ((item as AnyObject).value(forKey: "img") as? String)!
            
            if img.characters.count != 0 {
                if mes == nil{
                    
                    let chatBubbleData3 = ChatBubbleData(text: "", image:img as NSString?, date: str as Date, type: .opponent , tagg :1 )
                    self.addChatBubble(chatBubbleData3)
                }else{
                    
                    let chatBubbleData3 = ChatBubbleData(text: mes, image:img as NSString?, date: str as Date, type: .opponent , tagg:tagdata)
                    self.addChatBubble(chatBubbleData3)
                }
                
            }
        }else{
            
            let chatBubbleData3 = ChatBubbleData(text: mes, image:nil, date: str as Date, type: .opponent , tagg:tagdata)
            self.addChatBubble(chatBubbleData3)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func displayAlertMessage(messageToDisplay: String)
    {
        let alertController = UIAlertController(title: "Alert", message: messageToDisplay, preferredStyle: .alert)
        
        let OKAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction!) in
            
            // Code in this block will trigger when OK button tapped.
            print("Ok button tapped");
        }
        
        alertController.addAction(OKAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

extension chatsend: UITextFieldDelegate{
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Send button clicked
        textField.resignFirstResponder()
        // self.addRandomTypeChatBubble()
        textField.endEditing(true)
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        var text: String
        
        if string.characters.count > 0 {
            text = String(format:"%@%@",textField.text!, string);
        } else {
            var string = textField.text! as NSString
            text = string.substring(to: string.length - 1) as String
        }
        if text.characters.count > 0 {
            sendButton.isEnabled = true
        } else {
            sendButton.isEnabled = false
        }
        return true
    }
}

extension chatsend: UIImagePickerControllerDelegate{
    //MARK: Delegates
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingImage image: UIImage!, editingInfo: [AnyHashable: Any]!) {
        
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: { () -> Void in
            
        })
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [AnyHashable: Any]) {
        
        var chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage //2
        
        bubbleData = chosenImage
        
        //   bubbleData = ChatBubbleData(text: textField.text, image: chosenImage, date: Date(), type: getRandomChatDataType())
        uploadImage()
        // addChatBubble(bubbleData)
        picker.dismiss(animated: true, completion: { () -> Void in
            
        })
    }
}

